---
name: Help Wanted
about: Ask for help on forums
title: ''
labels: ''
assignees: ''

---

Please don't ask for help here. [Use the forums](https://forums.fast.ai)
